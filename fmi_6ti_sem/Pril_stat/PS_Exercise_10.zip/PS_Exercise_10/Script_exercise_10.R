                             ######### APPLIED STATISTICS -> EXERCISE 10 #######


rm(list=ls())                       ### Linear Discriminant Analysis ###  
                  
                                        # Simulated example of LDA #
# install.packages("MASS")
library("MASS")

# generate data
set.seed(1)

groupN=100 # number of cases per group
group1x=rnorm(n = groupN, mean = 0, sd = 4)
group1y=rnorm(n = groupN, mean = 0, sd = 4)
group2x=rnorm(n = groupN, mean = 10, sd = 5)
group2y=rnorm(n = groupN, mean = 10, sd = 5)

group1=data.frame(x = group1x, y = group1y, group = "A")
group2=data.frame(x = group2x, y = group2y, group = "B")
simData=rbind(group1, group2)

# LDA
simModel=lda(group ~ x + y, data = simData)
simModel
plot(simModel)

#scatterplot
plot(simData[,1:2], col = simData[,3])
points(simModel$means, pch = "+", cex = 3, col = c("black", "red"))

# draw discrimination line
predN=1000
newDataX <- seq(from = min(simData$x), to = max(simData$x), length.out = predN)
newDataY <- seq(from = min(simData$y), to = max(simData$y), length.out = predN)
newData <- expand.grid(x = newDataX, y = newDataY)
predData <- as.numeric(predict(simModel, newdata = newData)$class)
contour(x = newDataX, y = newDataY, z = matrix(predData, nrow = predN, ncol = predN), 
        levels = c(1, 2), add = TRUE, drawlabels = FALSE)

                                          # The Stock Market Data #
# install.packages("ISLR")
library(ISLR)

str(Smarket)
?Smarket
edit(Smarket)
summary(Smarket)
plot(Smarket)
cor(Smarket) # WRONG! -> Factor variable
cor(Smarket[,-9])
plot(Smarket$Volume)
                                              ### LDA for Smarket ###

attach(Smarket)
train=(Year<2005)
Smarket2005=Smarket[!train,]
Direction2005=Direction[!train]

ldaModel=lda(Direction~Lag1+Lag2,data=Smarket,subset=train)
ldaModel
summary(ldaModel)
plot(ldaModel)
plot(x=Lag1,y=Lag2, col = Direction)
points(ldaModel$means, pch = "+", cex = 3, col = c("black", "red"))

ldaPred=predict(ldaModel, Smarket[train,])
ldaClass=ldaPred$class
table(ldaClass,Direction[train])

ldaPred2005=predict(ldaModel, Smarket2005)
names(ldaPred2005)
str(ldaPred2005)

ldaClass2005=ldaPred2005$class
table(ldaClass2005,Direction2005)
mean(ldaClass==Direction2005)

sum(ldaPred2005$posterior[,1]>=.5)
sum(ldaPred2005$posterior[,1]<.5)
ldaPred2005$posterior[1:20,1]
ldaClass2005[1:20]
sum(ldaPred2005$posterior[,1]>.7)
summary(ldaPred2005$posterior)
detach(Smarket)

                                                  ### IRIS dataset ###
# install.packages("MASS")
library("MASS")
data("iris")
str(iris)
boxplot(iris[which(iris$Species=="setosa"),1:4])
boxplot(iris[which(iris$Species=="versicolor"),1:4])
boxplot(iris[which(iris$Species=="virginica"),1:4])
model1=lda(Species~.,data=iris)
model1

model2=lda(Species~Sepal.Length+Sepal.Width,data=iris)
model2
#scatterplot
plot(x=iris$Sepal.Length,iris$Sepal.Width, col = iris$Species)
points(model2$means, pch = "+", cex = 3, col = c(1,2,3))

# draw discrimination line
predN=1000
newDataX <- seq(from = min(iris$Sepal.Length), to = max(iris$Sepal.Length), length.out = predN)
newDataY <- seq(from = min(iris$Sepal.Width), to = max(iris$Sepal.Width), length.out = predN)
newData <- expand.grid(Sepal.Length = newDataX, Sepal.Width = newDataY)
predData <- as.numeric(predict(model2, newdata = newData)$class)
contour(x = newDataX, y = newDataY, z = matrix(predData, nrow = predN, ncol = predN), 
        levels = c(1,2,3), add = TRUE, drawlabels = FALSE)

                                                      #### Задача 1 ####
# Като изплозвате данните 'Default' от пакета 'ISLR', конструирайте линеен дискриминантен модел за
# предсказване на променливата 'default'. Какви изводи може да нправите?
